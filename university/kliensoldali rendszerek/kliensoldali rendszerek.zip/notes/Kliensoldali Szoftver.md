---
created: 20240901 23:53
tags:
  - 5semester
  - uni
  - client
cssclasses:
  - center-images
  - center-titles
  - markdown-preview-view
---
# Kliensoldali szoftver

A *kliensoldali szoftver* egy olyan program vagy alkalmazás, amely a felhasználó eszközén, például számítógépén, okostelefonon, vagy táblagépen fut. Ez a szoftver kommunikálhat egy távoli szerverrel, hogy különféle adatokat kérjen le, vagy műveleteket végezzen, de a végrehajtás és az adatok feldolgozása az ügyfél, azaz a felhasználó eszközén történik.

A [[Adatvezérelt rendszerek architektúrái#**Háromrétegű architektúra**|háromrétegű architektúrában]] általában a [[Megjelenítési Réteg|megjelenítésért]] felel, valamint az [[Üzleti Logika Réteg|üzleti logika]] egy részéért. A tárgy folyamán a [[Web Alapú Alkalmazás|web alapú alkalmazásokkal]] fogunk foglalkozni elsősorban.

![[Pasted image 20240909125728.png]]

